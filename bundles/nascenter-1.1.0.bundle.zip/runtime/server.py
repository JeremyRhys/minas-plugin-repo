#!/usr/bin/env python3
"""系统中心后端：性能监控 JSON API + 提供插件 UI（纯标准库）"""
import json
import os
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("PLUG_PORT", "8787"))
UI_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ui", "index.html")
CG = "/sys/fs/cgroup/system.slice"
CDIR = "/data/docker_data/containers"
NCPU = os.cpu_count() or 4

_lock = threading.Lock()
_state = {"ts": 0}


def rd(path, default=""):
    try:
        with open(path) as f:
            return f.read()
    except OSError:
        return default


def num(path, default=0):
    try:
        return int(rd(path).strip())
    except (ValueError, OSError):
        return default


def container_names():
    out = {}
    try:
        for cid in os.listdir(CDIR):
            try:
                cfg = json.load(open(os.path.join(CDIR, cid, "config.v2.json")))
                out[cid] = (cfg.get("Name") or cid[:12]).lstrip("/")
            except Exception:
                pass
    except OSError:
        pass
    return out


def cpu_core_ticks():
    out = []
    for line in rd("/proc/stat").splitlines():
        if line.startswith("cpu") and not line.startswith("cpu "):
            f = line.split()
            tot = sum(int(x) for x in f[1:])
            busy = tot - int(f[4]) - int(f[5])
            out.append((tot, busy))
    return out


def net_bytes():
    rx = tx = 0
    for line in rd("/proc/net/dev").splitlines()[2:]:
        if ":" not in line:
            continue
        name, rest = line.split(":", 1)
        if name.strip() == "lo":
            continue
        f = rest.split()
        if len(f) >= 9:
            rx += int(f[0])
            tx += int(f[8])
    return rx, tx


def disk_bytes():
    r = w = 0
    for line in rd("/proc/diskstats").splitlines():
        f = line.split()
        if len(f) < 10:
            continue
        if f[2] in ("mmcblk0", "sda", "sdb", "nvme0n1"):
            r += int(f[5]) * 512
            w += int(f[9]) * 512
    return r, w


def meminfo():
    m = {}
    for line in rd("/proc/meminfo").splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            parts = v.split()
            if parts:
                m[k] = int(parts[0]) * 1024
    return m


def temps():
    out = {}
    t = num("/sys/class/thermal/thermal_zone0/temp")
    if t:
        out["cpu"] = round(t / 1000.0, 1)
    disks = []
    for h in sorted(os.listdir("/sys/class/hwmon")) if os.path.isdir("/sys/class/hwmon") else []:
        base = os.path.join("/sys/class/hwmon", h)
        if rd(os.path.join(base, "name")).strip() == "drivetemp":
            v = num(os.path.join(base, "temp1_input"))
            if v:
                disks.append(round(v / 1000.0, 1))
    if disks:
        out["disk"] = disks
    return out


def disk_usage():
    out = []
    for path, label in (("/data", "eMMC 数据区"), ("/nas/pool0", "硬盘池"), ("/", "系统分区")):
        try:
            st = os.statvfs(path)
            total = st.f_blocks * st.f_frsize
            free = st.f_bavail * st.f_frsize
            out.append({"label": label, "total": total, "used": total - free, "ro": path == "/"})
        except OSError:
            pass
    return out


def top_procs(n=6):
    rows = []
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            rss = 0
            name = ""
            with open("/proc/%s/status" % pid) as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        rss = int(line.split()[1]) * 1024
                    elif line.startswith("Name:"):
                        name = line.split(":", 1)[1].strip()
            if rss:
                rows.append((rss, int(pid), name))
        except (OSError, ValueError):
            pass
    rows.sort(reverse=True)
    return [{"name": nm, "pid": p, "rss": rss} for rss, p, nm in rows[:n]]


def _sh(cmd, timeout=8):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL, timeout=timeout).decode("utf-8", "ignore")
    except Exception:
        return ""


_drives_cache = {"t": 0.0, "v": []}


def drives_info():
    """硬盘健康：smartctl -j（60 秒缓存）"""
    if time.time() - _drives_cache["t"] < 60:
        return _drives_cache["v"]
    out = []
    for dev in ("sda", "sdb", "sdc", "sdd"):
        if not os.path.exists("/dev/" + dev):
            continue
        try:
            d = json.loads(_sh("smartctl -j -H -i -A /dev/" + dev) or "{}")
        except Exception:
            d = {}
        temp = None
        tinfo = d.get("temperature") or {}
        if isinstance(tinfo, dict):
            temp = tinfo.get("current")
        attrs = {}
        for row in ((d.get("ata_smart_attributes") or {}).get("table") or []):
            aid = row.get("id")
            if aid:
                attrs[aid] = row.get("raw", {}).get("value")
        if temp is None:
            temp = attrs.get(194)
        cap = (d.get("user_capacity") or {}).get("bytes")
        health = ((d.get("smart_status") or {}).get("passed"))
        out.append({
            "dev": "/dev/" + dev,
            "model": (d.get("model_name") or d.get("device", {}).get("name") or "未知").strip(),
            "serial": (d.get("serial_number") or "-").strip(),
            "capacity": cap,
            "rotation": d.get("rotation_rate"),
            "temp": int(temp) if temp else None,
            "health": health,
            "hours": d.get("power_on_time", {}).get("hours"),
            "reallocated": attrs.get(5),
            "pending": attrs.get(197),
            "uncorrectable": attrs.get(198),
            "crc": attrs.get(199),
        })
    _drives_cache.update({"t": time.time(), "v": out})
    return out


_iface_cache = {"t": 0.0, "v": [], "tot": {}}


def net_ifaces():
    """网卡：地址 / 状态 / 速率 / 累计字节（15 秒缓存）+ 实时速率（每秒采样）"""
    now = time.time()
    if now - _iface_cache["t"] > 15:
        ipv4 = {}
        for line in _sh("ip -4 -o addr show").splitlines():
            p = line.split()
            if len(p) >= 4 and p[2] == "inet":
                ipv4[p[1]] = p[3]
        rows, tot = [], {}
        try:
            names = sorted(n for n in os.listdir("/sys/class/net") if n != "lo")
        except OSError:
            names = []
        skip_prefix = ("docker", "veth", "br-", "sit", "tun")
        for n in names:
            base = "/sys/class/net/" + n
            rx = num(base + "/statistics/rx_bytes")
            tx = num(base + "/statistics/tx_bytes")
            tot[n] = (rx, tx, now)
            if n.startswith(skip_prefix):
                continue
            rows.append({
                "name": n,
                "ip": ipv4.get(n, "-"),
                "state": (rd(base + "/operstate", "unknown")).strip(),
                "speed": num(base + "/speed", 0),
                "rx": rx,
                "tx": tx,
            })
        _iface_cache["t"] = now
        _iface_cache["v"] = rows
        _iface_cache["tot"] = tot
        return rows
    # 实时速率
    res = []
    for r in _iface_cache["v"]:
        prev = _iface_cache["tot"].get(r["name"])
        row = dict(r)
        if prev:
            dt = max(now - prev[2], 0.2)
            row["rx_rate"] = max(0, r["rx"] - prev[0]) / dt
            row["tx_rate"] = max(0, r["tx"] - prev[1]) / dt
        res.append(row)
    return res


_sys_cache = {"t": 0.0, "v": {}}
_docker_cache = {"t": 0.0, "v": {}}


def sys_info():
    """系统信息（30 秒缓存）"""
    if time.time() - _sys_cache["t"] < 30 and _sys_cache["v"]:
        return _sys_cache["v"]
    if time.time() - _docker_cache["t"] > 120:
        dc = {}
        try:
            dc["images"] = len([x for x in _sh("DOCKER_CONFIG=/data/.docker /data/rootshell/bin/docker images -q").splitlines() if x])
            dc["containers"] = len([x for x in _sh("DOCKER_CONFIG=/data/.docker /data/rootshell/bin/docker ps -aq").splitlines() if x])
            dc["running"] = len([x for x in _sh("DOCKER_CONFIG=/data/.docker /data/rootshell/bin/docker ps -q").splitlines() if x])
        except Exception:
            pass
        _docker_cache.update({"t": time.time(), "v": dc})
    u = os.uname()
    listening = 0
    for f in ("/proc/net/tcp", "/proc/net/tcp6"):
        for line in rd(f).splitlines()[1:]:
            p = line.split()
            if len(p) > 3 and p[3] == "0A":
                listening += 1
    btime = 0
    for line in rd("/proc/stat").splitlines():
        if line.startswith("btime"):
            btime = int(line.split()[1])
    info = {
        "kernel": u.release,
        "machine": u.machine,
        "boot": btime,
        "procs": len([p for p in os.listdir("/proc") if p.isdigit()]),
        "listening": listening,
        "cpu_model": "",
        "docker": _docker_cache["v"],
    }
    # CPU 型号：ARM 上 /proc/cpuinfo 只有 CPU part 编号，做一层映射
    part = ""
    for line in rd("/proc/cpuinfo").splitlines():
        low = line.lower()
        if low.startswith("cpu part"):
            part = line.split(":", 1)[1].strip()
        elif low.startswith("model name") or low.startswith("hardware"):
            info["cpu_model"] = line.split(":", 1)[1].strip()
    if not info["cpu_model"] and part:
        pmap = {"0xd05": "ARM Cortex-A55", "0xd0b": "ARM Cortex-A76", "0xd03": "ARM Cortex-A53",
                "0xd07": "ARM Cortex-A57", "0xd08": "ARM Cortex-A72", "0xd09": "ARM Cortex-A73",
                "0xd0d": "ARM Cortex-A77", "0xd41": "ARM Cortex-A78", "0xd44": "ARM Cortex-X1"}
        info["cpu_model"] = pmap.get(part, "ARM (CPU part " + part + ")")
    if not info["cpu_model"]:
        dt = rd("/sys/firmware/devicetree/base/model").strip("\x00\n ")
        if dt:
            info["cpu_model"] = dt
    board = rd("/sys/firmware/devicetree/base/model").strip("\x00\n ")
    if board:
        info["board"] = board
    _sys_cache.update({"t": time.time(), "v": info})
    return info


def containers(names, cpu_prev):
    out = []
    try:
        scopes = os.listdir(CG)
    except OSError:
        return out
    for scope in scopes:
        if not scope.startswith("docker-") or not scope.endswith(".scope"):
            continue
        cid = scope[len("docker-"):-len(".scope")]
        base = os.path.join(CG, scope)
        mem = num(os.path.join(base, "memory.current"))
        pids = num(os.path.join(base, "pids.current"))
        usec = 0
        for line in rd(os.path.join(base, "cpu.stat")).splitlines():
            if line.startswith("usage_usec"):
                usec = int(line.split()[1])
        delta = usec - cpu_prev.get(cid, usec)
        out.append({
            "name": names.get(cid, cid[:12]),
            "id": cid,
            "mem": mem,
            "pids": pids,
            "cpu_usec": usec,
            "cpu": max(0.0, delta / 1e6),  # 采样周期 1s -> 秒数即核数
        })
    out.sort(key=lambda c: c["mem"], reverse=True)
    return out


def sampler():
    prev_cpu = None
    prev_net = None
    prev_disk = None
    prev_t = None
    names = {}
    names_t = 0.0
    cprev = {}
    procs = []
    procs_t = 0.0
    while True:
        t = time.time()
        if t - names_t > 30:
            names = container_names()
            names_t = t
        if t - procs_t > 5:
            procs = top_procs()
            procs_t = t
        cur_cpu = cpu_core_ticks()
        cur_net = net_bytes()
        cur_disk = disk_bytes()
        m = meminfo()
        dt = (t - prev_t) if prev_t else 1.0
        dt = dt if dt > 0.05 else 0.05

        cores = []
        if prev_cpu and len(prev_cpu) == len(cur_cpu):
            for i, (tot, busy) in enumerate(cur_cpu):
                d_tot = tot - prev_cpu[i][0]
                d_busy = busy - prev_cpu[i][1]
                cores.append(round(100.0 * d_busy / d_tot, 1) if d_tot > 0 else 0.0)
        else:
            cores = [0.0] * len(cur_cpu)

        rx = tx = 0.0
        if prev_net:
            rx = max(0, cur_net[0] - prev_net[0]) / dt
            tx = max(0, cur_net[1] - prev_net[1]) / dt
        dr = dw = 0.0
        if prev_disk:
            dr = max(0, cur_disk[0] - prev_disk[0]) / dt
            dw = max(0, cur_disk[1] - prev_disk[1]) / dt

        la = rd("/proc/loadavg").split()
        up = float(rd("/proc/uptime").split()[0]) if rd("/proc/uptime") else 0
        cs = containers(names, cprev)
        cprev = {c["id"]: c["cpu_usec"] for c in cs}

        total = m.get("MemTotal", 1)
        avail = m.get("MemAvailable", 0)
        sw_t = m.get("SwapTotal", 0)
        sw_f = m.get("SwapFree", 0)

        snap = {
            "ts": int(t * 1000),
            "host": os.uname().nodename,
            "ncpu": NCPU,
            "cpu": {"cores": cores, "total": round(sum(cores) / max(len(cores), 1), 1)},
            "load": [float(x) for x in la[:3]] if len(la) >= 3 else [0, 0, 0],
            "mem": {"total": total, "avail": avail, "used": total - avail,
                    "cache": m.get("Cached", 0) + m.get("Buffers", 0)},
            "swap": {"total": sw_t, "used": sw_t - sw_f},
            "temp": temps(),
            "uptime": int(up),
            "disk": disk_usage(),
            "io": {"read": dr, "write": dw},
            "net": {"rx": rx, "tx": tx},
            "containers": cs,
            "procs": procs,
            "drives": drives_info(),
            "ifaces": net_ifaces(),
            "sys": sys_info(),
        }
        with _lock:
            _state.clear()
            _state.update(snap)

        prev_cpu, prev_net, prev_disk, prev_t = cur_cpu, cur_net, cur_disk, t
        time.sleep(1)



class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path.startswith("/api/stats"):
            with _lock:
                body = json.dumps(_state).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path.startswith("/api/health"):
            body = json.dumps({"ok": True, "service": "nascenter"}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path in ("/", "/index.html"):
            try:
                body = open(UI_FILE, "rb").read()
            except OSError:
                body = "<h1>UI 文件缺失</h1>".encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(302)
            self.send_header("Location", "/")
            self.end_headers()


if __name__ == "__main__":
    threading.Thread(target=sampler, daemon=True).start()
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print("monitor on :%d" % PORT, flush=True)
    srv.serve_forever()
