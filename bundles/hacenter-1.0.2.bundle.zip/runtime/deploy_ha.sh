#!/bin/sh
# 部署 Home Assistant Core 容器。可重复执行（幂等）。
# 关键点：HA 官方镜像的层是 zstd 压缩，Docker 20.10 直接 pull 会报
#   "failed to register layer: archive/tar: invalid tar header"
# 所以用 skopeo 重新压成 gzip 再 docker load。
set -u
DATA="${HA_DATA:-/data/rootshell/homeassistant}"
DOCKER="${DOCKER_BIN:-/data/docker/docker}"
IMG="ghcr.io/home-assistant/home-assistant"
TAG="stable"
LOCK=/tmp/hacenter-deploy.lock

echo $$ > "$LOCK"
trap 'rm -f "$LOCK"' EXIT

say() { echo "[$(date +%H:%M:%S)] $*"; }

mkdir -p "$DATA/config" "$DATA/img"

if ! $DOCKER images -q home-assistant:stable 2>/dev/null | grep -q .; then
    say "[1/3] 拉 skopeo 并转换镜像（629MB 压缩层，5 分钟量级）"
    $DOCKER pull -q quay.io/skopeo/stable:latest || { say "skopeo 镜像拉取失败"; exit 1; }
    rm -f "$DATA/img/ha.tar"
    if ! $DOCKER run --rm --network host -v "$DATA/img:/out" quay.io/skopeo/stable:latest \
        copy --dest-compress-format gzip --dest-compress-level 6 --format v2s2 \
        "docker://$IMG:$TAG" "docker-archive:/out/ha.tar:home-assistant:$TAG" 2>&1 | tail -8; then
        say "skopeo 转换失败"; exit 1
    fi
    say "[2/3] docker load"
    $DOCKER load -i "$DATA/img/ha.tar" || { say "docker load 失败"; exit 1; }
    rm -f "$DATA/img/ha.tar"
else
    say "镜像已存在，跳过拉取"
fi

say "[3/3] 创建/重建容器"
$DOCKER rm -f homeassistant >/dev/null 2>&1
$DOCKER run -d --name homeassistant --restart=unless-stopped --network host \
    --memory=800m -e TZ=Asia/Shanghai \
    -v "$DATA/config:/config" \
    home-assistant:stable || { say "容器创建失败"; exit 1; }

say "完成：HA 首次启动约 30-60 秒，之后浏览器打开 http://<NAS-IP>:8123 创建账号"
