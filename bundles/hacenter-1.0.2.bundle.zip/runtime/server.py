#!/usr/bin/env python3
"""HA 控制中心后端：桥接本机 Home Assistant Core 的 REST API（纯标准库）。

只监听 127.0.0.1，由 nginx 反代 /plugin/<uid>/hacenter/api/* 过来。
不保存 HA 账号密码：只保存用户在 HA 里自建的「长期访问令牌」，文件 0600。
"""
import json
import os
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

PORT = int(os.environ.get("PLUG_PORT", "9304"))
VERSION = "1.0.2"
DOCKER = os.environ.get("DOCKER_BIN", "/data/docker/docker")
DATA = os.environ.get("HA_DATA", "/data/rootshell/homeassistant")
CONF = os.path.join(DATA, "config")
TOKEN_FILE = os.path.join(DATA, "token")
DEPLOY_LOG = os.path.join(DATA, "deploy.log")
LOCK = "/tmp/hacenter-deploy.lock"
CONTAINER = "homeassistant"
HA = "http://127.0.0.1:8123"

CONTROL_DOMAINS = ("light", "switch", "fan", "cover", "input_boolean", "climate", "scene", "script", "humidifier")
SENSOR_DOMAINS = ("sensor", "binary_sensor", "weather", "person", "sun")

_cache = {}
_lock = threading.Lock()


def _cache_get(key, ttl):
    with _lock:
        hit = _cache.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    return None


def _cache_put(key, val):
    with _lock:
        _cache[key] = (time.time(), val)


def read_token():
    try:
        with open(TOKEN_FILE) as f:
            t = f.read().strip()
        return t or None
    except OSError:
        return None


def write_token(token):
    os.makedirs(DATA, exist_ok=True)
    fd = os.open(TOKEN_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(token.strip() + "\n")
    os.chmod(TOKEN_FILE, 0o600)


def ha_call(path, method="GET", payload=None, timeout=6):
    """调 HA REST；返回 (code, obj)。没有 token 时 code=401。"""
    token = read_token()
    if not token:
        return 401, {"error": "no_token"}
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(HA + path, data=data, method=method)
    req.add_header("Authorization", "Bearer " + token)
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read()
            return r.status, (json.loads(body) if body else {})
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read() or b"{}")
        except Exception:
            body = {}
        return e.code, body
    except Exception as e:
        return 0, {"error": str(e)}


def sh(cmd, timeout=15):
    try:
        return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True,
                              timeout=timeout).stdout.decode("utf-8", "ignore").strip()
    except Exception:
        return ""


def container_info():
    hit = _cache_get("ctr", 3)
    if hit is not None:
        return hit
    info = {"exists": False, "running": False, "image": "", "started": "", "mem": 0, "net_mode": "", "mem_limit": 0}
    out = sh([DOCKER, "inspect", CONTAINER], timeout=8)
    if out:
        try:
            d = json.loads(out)[0]
            st = d.get("State") or {}
            hc = d.get("HostConfig") or {}
            info.update({
                "exists": True,
                "running": bool(st.get("Running")),
                "status": st.get("Status") or "",
                "image": (d.get("Config") or {}).get("Image") or "",
                "started": st.get("StartedAt") or "",
                "net_mode": hc.get("NetworkMode") or "",
                "mem_limit": hc.get("Memory") or 0,
                "id": (d.get("Id") or "")[:12],
            })
            cg = "/sys/fs/cgroup/system.slice/docker-%s.scope/memory.current" % (d.get("Id") or "")
            try:
                info["mem"] = int(open(cg).read().strip())
            except OSError:
                info["mem"] = 0
        except Exception:
            pass
    _cache_put("ctr", info)
    return info


def image_present():
    hit = _cache_get("img", 10)
    if hit is not None:
        return hit
    v = bool(sh([DOCKER, "images", "-q", "home-assistant:stable"], timeout=8))
    _cache_put("img", v)
    return v


def deploying():
    if not os.path.exists(LOCK):
        return False
    pid = ""
    try:
        pid = open(LOCK).read().strip()
    except OSError:
        pass
    if pid and os.path.isdir("/proc/" + pid):
        return True
    try:
        os.remove(LOCK)
    except OSError:
        pass
    return False


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.168.1.1", 9))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "NAS-IP"


def dir_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def tail(path, n=6):
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 4096))
            lines = f.read().decode("utf-8", "ignore").splitlines()
        return [l.strip() for l in lines if l.strip()][-n:]
    except OSError:
        return []


def overview():
    ctr = container_info()
    token = read_token()
    stage = "not_deployed"
    if ctr["running"]:
        stage = "no_token" if not token else "starting"
    elif ctr["exists"]:
        stage = "stopped"
    elif deploying():
        stage = "deploying"
    elif image_present():
        stage = "image_ready"

    ha = {"version": "", "name": "", "uptime": "", "counts": {}}
    if stage in ("starting",):
        code, cfg = ha_call("/api/config", timeout=4)
        if code == 200:
            stage = "ready"
            ha["version"] = cfg.get("version", "")
            ha["name"] = cfg.get("location_name", "")
            ha["internal_url"] = cfg.get("internal_url", "")
            code2, states = ha_call("/api/states", timeout=5)
            if code2 == 200 and isinstance(states, list):
                ha["counts"]["entities"] = len(states)
                ha["counts"]["controls"] = sum(1 for s in states if s.get("entity_id", "").split(".")[0] in CONTROL_DOMAINS)
        elif code == 401 and token:
            stage = "bad_token"

    if ctr["running"] and stage in ("ready", "starting"):
        started = ctr.get("started") or ""
        ha["uptime"] = started

    st = os.statvfs("/data")
    free = st.f_bavail * st.f_frsize
    ha_conf = dir_size(CONF) if os.path.isdir(CONF) else 0

    return {
        "ok": True,
        "stage": stage,
        "container": {k: ctr.get(k) for k in ("exists", "running", "status", "image", "started", "mem", "mem_limit", "net_mode")},
        "ha": ha,
        "deploying": deploying(),
        "deploy_tail": tail(DEPLOY_LOG, 4) if stage in ("deploying", "image_ready", "stopped") else [],
        "disk": {"data_free": free, "ha_config": ha_conf},
        "panel_url": "http://%s:8123" % lan_ip(),
        "token_set": bool(token),
        "version": VERSION,
    }


def entities():
    hit = _cache_get("ent", 4)
    if hit is not None:
        return hit
    code, states = ha_call("/api/states", timeout=8)
    if code != 200 or not isinstance(states, list):
        return {"ok": False, "code": code, "error": (states or {}).get("error", "ha_unreachable")}
    ctrls, sensors = [], []
    for s in states:
        eid = s.get("entity_id") or ""
        dom = eid.split(".")[0]
        attrs = s.get("attributes") or {}
        name = attrs.get("friendly_name") or eid
        if attrs.get("hidden_by") or attrs.get("hidden"):
            continue
        item = {
            "entity_id": eid,
            "domain": dom,
            "name": name,
            "state": s.get("state"),
            "unit": attrs.get("unit_of_measurement") or "",
            "device_class": attrs.get("device_class") or "",
            "supported": attrs.get("supported_features"),
        }
        if dom in CONTROL_DOMAINS:
            ctrls.append(item)
        elif dom in SENSOR_DOMAINS:
            sensors.append(item)
    # 传感器只保留有意义的：有单位的、binary_sensor；sun/备份管理器这类噪声不放
    sensors = [s for s in sensors
               if s["domain"] != "sun"
               and not s["entity_id"].startswith("sensor.sun_")
               and not s["name"].lower().startswith("backup")
               and "备份" not in s["name"]]
    sensors.sort(key=lambda x: (0 if x["unit"] else 1, x["domain"], x["name"]))
    ctrls.sort(key=lambda x: (CONTROL_DOMAINS.index(x["domain"]), x["name"]))
    out = {"ok": True, "controls": ctrls[:60], "sensors": sensors[:12],
           "counts": {"controls": len(ctrls), "sensors": len(sensors)}}
    _cache_put("ent", out)
    return out


def toggle(eid, action=None):
    if not eid or "." not in eid:
        return 400, {"ok": False, "error": "bad entity_id"}
    dom, _ = eid.split(".", 1)
    if dom == "cover":
        svc = "cover.close_cover" if action in ("off", "close", "close_cover") else "cover.open_cover"
    else:
        svc = "homeassistant.turn_off" if action in ("off", "turn_off") else "homeassistant.turn_on"
    code, resp = ha_call("/api/services/" + svc.replace(".", "/", 1), method="POST",
                         payload={"entity_id": eid}, timeout=8)
    with _lock:
        _cache.pop("ent", None)
    return (200 if code in (200, 201) else 502), {"ok": code in (200, 201), "service": svc, "upstream": code, "resp": resp}


class Handler(BaseHTTPRequestHandler):
    server_version = "hacenter"

    def log_message(self, *a):
        pass

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return {}

    def do_GET(self):
        u = urlparse(self.path)
        p, q = u.path, parse_qs(u.query)
        if p == "/api/health":
            return self._json(200, {"ok": True, "service": "hacenter", "v": VERSION})
        if p == "/api/overview":
            return self._json(200, overview())
        if p == "/api/entities":
            return self._json(200, entities())
        if p == "/api/deploy-progress":
            return self._json(200, {"ok": True, "deploying": deploying(),
                                    "image": image_present(), "tail": tail(DEPLOY_LOG, 8)})
        if p == "/api/logs":
            n = int((q.get("n") or ["40"])[0])
            return self._json(200, {"ok": True, "lines": tail(DEPLOY_LOG, min(n, 200))})
        return self._json(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        p = urlparse(self.path).path
        if p == "/api/toggle":
            body = self._body()
            code, obj = toggle(body.get("entity_id"), body.get("action"))
            return self._json(code, obj)
        if p == "/api/setup":
            token = (self._body().get("token") or "").strip()
            if len(token) < 20:
                return self._json(400, {"ok": False, "error": "token 太短，看起来不是长期访问令牌"})
            old = read_token()
            write_token(token)
            code, cfg = ha_call("/api/config", timeout=6)
            if code != 200:
                if old:
                    write_token(old)
                else:
                    os.remove(TOKEN_FILE) if os.path.exists(TOKEN_FILE) else None
                return self._json(401, {"ok": False, "error": "令牌校验失败", "upstream": code, "resp": cfg})
            with _lock:
                _cache.clear()
            return self._json(200, {"ok": True, "version": cfg.get("version", ""), "name": cfg.get("location_name", "")})
        if p == "/api/setup/clear":
            try:
                os.remove(TOKEN_FILE)
            except OSError:
                pass
            with _lock:
                _cache.clear()
            return self._json(200, {"ok": True})
        if p == "/api/deploy":
            if deploying():
                return self._json(409, {"ok": False, "error": "已有部署在进行"})
            script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "deploy_ha.sh")
            if not os.path.exists(script):
                return self._json(500, {"ok": False, "error": "deploy_ha.sh 缺失"})
            with open(LOCK, "w") as f:
                f.write("0")
            subprocess.Popen(["/bin/sh", script], stdout=open(DEPLOY_LOG, "ab"),
                             stderr=subprocess.STDOUT, start_new_session=True)
            time.sleep(0.3)
            return self._json(200, {"ok": True, "started": True})
        return self._json(404, {"ok": False, "error": "not found"})


if __name__ == "__main__":
    print("hacenter on :%d" % PORT, flush=True)
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
