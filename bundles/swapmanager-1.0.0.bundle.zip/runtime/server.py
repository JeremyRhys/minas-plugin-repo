#!/usr/bin/env python3
"""Swap 管理后端：创建/启停/删除 /data/swapfile、swappiness、开机自启（纯标准库）"""

import json
import os
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("PLUG_PORT", "8791"))
DATA = "/data/swapmanager"
SWAPFILE = "/data/swapfile"
CRON = "/etc/cron.d/swapmanager"
DISABLED = os.path.join(DATA, "disabled")
UI_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ui")
LOCK = threading.Lock()


def sh(args, timeout=600):
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as error:
        return subprocess.CompletedProcess(args, 1, "", str(error))


def meminfo():
    out = {}
    try:
        for line in open("/proc/meminfo"):
            key, value = line.split(":", 1)
            out[key] = int(value.strip().split()[0])
    except OSError:
        pass
    return out


def swap_active():
    try:
        for line in open("/proc/swaps").read().splitlines()[1:]:
            if line.split()[0] == SWAPFILE:
                return True
    except OSError:
        pass
    return False


def file_size():
    try:
        return os.path.getsize(SWAPFILE)
    except OSError:
        return 0


def swappiness():
    try:
        return int(open("/proc/sys/vm/swappiness").read().strip())
    except OSError:
        return 60


def write_autostart(value):
    os.makedirs(DATA, exist_ok=True)
    script = os.path.join(DATA, "autostart.sh")
    with open(script, "w") as handle:
        handle.write("#!/bin/sh\n")
        handle.write("[ -f /data/swapfile ] || exit 0\n")
        handle.write("grep -q /data/swapfile /proc/swaps 2>/dev/null || swapon /data/swapfile 2>/dev/null\n")
        handle.write("echo %d > /proc/sys/vm/swappiness 2>/dev/null\n" % value)
    os.chmod(script, 0o755)
    with open(CRON, "w") as handle:
        handle.write("* * * * * root sh /data/swapmanager/autostart.sh >/dev/null 2>&1\n")
        handle.write("* * * * * root systemctl is-active -q swapmanager.service || systemctl start swapmanager.service\n")
    os.chmod(CRON, 0o644)


def remove_autostart():
    try:
        os.remove(CRON)
    except OSError:
        pass
    try:
        os.remove(DISABLED)
    except OSError:
        pass


def status():
    info = meminfo()
    total = info.get("SwapTotal", 0)
    free = info.get("SwapFree", 0)
    return {
        "ok": True,
        "active": swap_active(),
        "total_kb": total,
        "used_kb": max(total - free, 0),
        "file": SWAPFILE,
        "file_size": file_size(),
        "swappiness": swappiness(),
        "autostart": os.path.isfile(CRON),
        "disabled": os.path.isfile(DISABLED),
        "disk_free_kb": sh(["df", "-k", "/data"]).stdout.splitlines()[-1].split()[3]
        if sh(["df", "-k", "/data"]).returncode == 0
        else 0,
    }


def create(size_mb):
    if not 256 <= size_mb <= 8192 or size_mb % 256:
        raise ValueError("容量需为 256–8192 MB 之间、且是 256 的倍数")
    if os.path.exists(SWAPFILE) and file_size() > 0:
        if not swap_active():
            result = sh(["swapon", SWAPFILE])
            if result.returncode != 0:
                raise RuntimeError(result.stderr.strip() or "swapon 失败")
            write_autostart(swappiness())
            return status()
        raise ValueError("swap 文件已存在并已启用")
    free_kb = int(sh(["df", "-k", "/data"]).stdout.splitlines()[-1].split()[3])
    if free_kb < size_mb * 1024 + 512 * 1024:
        raise ValueError("磁盘空间不足（至少留 512 MB）")
    os.makedirs(DATA, exist_ok=True)
    result = sh(["fallocate", "-l", f"{size_mb}M", SWAPFILE])
    if result.returncode != 0 or file_size() != size_mb * 1024 * 1024:
        try:
            os.remove(SWAPFILE)
        except OSError:
            pass
        result = sh(["dd", "if=/dev/zero", f"of={SWAPFILE}", "bs=1M", f"count={size_mb}", "status=none"])
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or "创建 swap 文件失败")
    os.chmod(SWAPFILE, 0o600)
    result = sh(["mkswap", SWAPFILE])
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "mkswap 失败")
    result = sh(["swapon", SWAPFILE])
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "swapon 失败")
    write_autostart(swappiness())
    return status()


def turn_off():
    if swap_active():
        result = sh(["swapoff", SWAPFILE])
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or "swapoff 失败")
    return status()


def turn_on():
    if not os.path.isfile(SWAPFILE):
        raise ValueError("还没有 swap 文件，请先创建")
    if not swap_active():
        result = sh(["swapon", SWAPFILE])
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or "swapon 失败")
    write_autostart(swappiness())
    return status()


def delete():
    if swap_active():
        sh(["swapoff", SWAPFILE])
    try:
        os.remove(SWAPFILE)
    except OSError:
        pass
    remove_autostart()
    os.makedirs(DATA, exist_ok=True)
    open(DISABLED, "w").write("deleted by swapmanager\n")
    return status()


def set_swappiness(value):
    if not 0 <= value <= 100:
        raise ValueError("swappiness 需在 0–100")
    result = sh(["sh", "-c", f"echo {value} > /proc/sys/vm/swappiness"])
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "写入 swappiness 失败")
    if os.path.isfile(CRON):
        write_autostart(value)
    return status()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _json(self, code, value):
        body = json.dumps(value).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return {}
        if length <= 0 or length > 4096:
            return {}
        try:
            value = json.loads(self.rfile.read(length))
            return value if isinstance(value, dict) else {}
        except json.JSONDecodeError:
            return {}

    def do_GET(self):
        if self.path.startswith("/api/status") or self.path.startswith("/api/health"):
            self._json(200, status())
        elif self.path in ("/", "/index.html"):
            try:
                body = open(os.path.join(UI_DIR, "index.html"), "rb").read()
            except OSError:
                body = "<h1>UI 文件缺失</h1>".encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self._json(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        body = self._body()
        try:
            with LOCK:
                if self.path.startswith("/api/create"):
                    result = create(int(body.get("size_mb", 0)))
                elif self.path.startswith("/api/on"):
                    result = turn_on()
                elif self.path.startswith("/api/off"):
                    result = turn_off()
                elif self.path.startswith("/api/delete"):
                    result = delete()
                elif self.path.startswith("/api/swappiness"):
                    result = set_swappiness(int(body.get("value", 60)))
                else:
                    self._json(404, {"ok": False, "error": "not found"})
                    return
            self._json(200, result)
        except (ValueError, RuntimeError) as error:
            self._json(400, {"ok": False, "error": str(error)})


if __name__ == "__main__":
    os.makedirs(DATA, exist_ok=True)
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print("swapmanager on :%d" % PORT, flush=True)
    srv.serve_forever()
